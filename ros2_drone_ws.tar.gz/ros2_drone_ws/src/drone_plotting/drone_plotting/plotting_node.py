#!/usr/bin/env python3
# ============================================================
#  plotting_node.py
#  Nœud ROS 2 – Visualisation temps réel
#
#  Ce nœud fait deux choses :
#    1. DÉTECTION : reçoit l'image caméra, détecte la sphère
#       rouge par filtrage HSV (OpenCV), publie les coordonnées
#       pixel du centroïde sur /drone/pixel_coords
#
#    2. AFFICHAGE : fenêtre matplotlib avec 9 sous-graphes :
#       ┌────────────┬────────────┬────────────┐
#       │  Position  │  Vitesse   │  Accél.    │
#       │  x, y, z   │  lin. xyz  │  lin. xyz  │
#       ├────────────┼────────────┼────────────┤
#       │  Force     │  Couple    │  Accél.    │
#       │  Fx,Fy,Fz  │  Tx,Ty,Tz  │  ang. xyz  │
#       ├────────────┼────────────┼────────────┤
#       │ Trajectoire│  Pixels    │  Caméra    │
#       │   3D XYZ   │  u(t),v(t) │  + détect. │
#       └────────────┴────────────┴────────────┘
#
#  Souscrit à :
#    /drone/state       DroneState     – état complet
#    /camera/image_raw  sensor_msgs/Image – flux caméra
#
#  Publie sur :
#    /drone/pixel_coords geometry_msgs/Point  – (u, v, 0) pixels
# ============================================================

import threading
import collections
import numpy as np
import cv2
from cv_bridge import CvBridge

import rclpy
from rclpy.node import Node
from drone_msgs.msg import DroneState
from sensor_msgs.msg import Image
from geometry_msgs.msg import Point

import matplotlib
matplotlib.use('TkAgg')   # backend interactif (changer en 'Qt5Agg' si besoin)
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401


# ── Longueur maximale des buffers ──────────────────────────
MAX_PTS = 500


class DronePlottingNode(Node):

    def __init__(self):
        super().__init__('drone_plotting')

        self.bridge = CvBridge()
        self.lock   = threading.Lock()

        # ── Buffers de données (deque = file circulaire) ───
        self.t_buf       = collections.deque(maxlen=MAX_PTS)

        self.pos_x       = collections.deque(maxlen=MAX_PTS)
        self.pos_y       = collections.deque(maxlen=MAX_PTS)
        self.pos_z       = collections.deque(maxlen=MAX_PTS)

        self.vel_x       = collections.deque(maxlen=MAX_PTS)
        self.vel_y       = collections.deque(maxlen=MAX_PTS)
        self.vel_z       = collections.deque(maxlen=MAX_PTS)

        self.acc_lx      = collections.deque(maxlen=MAX_PTS)
        self.acc_ly      = collections.deque(maxlen=MAX_PTS)
        self.acc_lz      = collections.deque(maxlen=MAX_PTS)

        self.acc_ax      = collections.deque(maxlen=MAX_PTS)
        self.acc_ay      = collections.deque(maxlen=MAX_PTS)
        self.acc_az      = collections.deque(maxlen=MAX_PTS)

        self.force_x     = collections.deque(maxlen=MAX_PTS)
        self.force_y     = collections.deque(maxlen=MAX_PTS)
        self.force_z     = collections.deque(maxlen=MAX_PTS)

        self.torque_x    = collections.deque(maxlen=MAX_PTS)
        self.torque_y    = collections.deque(maxlen=MAX_PTS)
        self.torque_z    = collections.deque(maxlen=MAX_PTS)

        self.pixel_u     = collections.deque(maxlen=MAX_PTS)
        self.pixel_v     = collections.deque(maxlen=MAX_PTS)
        self.pixel_t     = collections.deque(maxlen=MAX_PTS)

        self.t0          = None          # temps de référence (premier message)
        self.latest_img  = None          # dernière image OpenCV traitée
        self.detect_u    = None          # coordonnée pixel u du centroïde
        self.detect_v    = None          # coordonnée pixel v du centroïde

        # ── Publishers ─────────────────────────────────────
        self.pixel_pub = self.create_publisher(
            Point, '/drone/pixel_coords', 10)

        # ── Subscribers ────────────────────────────────────
        self.state_sub = self.create_subscription(
            DroneState, '/drone/state', self._state_cb, 10)
        self.image_sub = self.create_subscription(
            Image, '/camera/image_raw', self._image_cb, 10)

        self.get_logger().info('[Plotting] Nœud initialisé')

    # ──────────────────────────────────────────────────────
    def _state_cb(self, msg: DroneState):
        """Reçoit l'état du drone et remplit les buffers."""
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9

        with self.lock:
            if self.t0 is None:
                self.t0 = stamp
            t = stamp - self.t0

            self.t_buf.append(t)

            self.pos_x.append(msg.pose.position.x)
            self.pos_y.append(msg.pose.position.y)
            self.pos_z.append(msg.pose.position.z)

            self.vel_x.append(msg.twist.linear.x)
            self.vel_y.append(msg.twist.linear.y)
            self.vel_z.append(msg.twist.linear.z)

            self.acc_lx.append(msg.accel.linear.x)
            self.acc_ly.append(msg.accel.linear.y)
            self.acc_lz.append(msg.accel.linear.z)

            self.acc_ax.append(msg.accel.angular.x)
            self.acc_ay.append(msg.accel.angular.y)
            self.acc_az.append(msg.accel.angular.z)

            self.force_x.append(msg.force.x)
            self.force_y.append(msg.force.y)
            self.force_z.append(msg.force.z)

            self.torque_x.append(msg.torque.x)
            self.torque_y.append(msg.torque.y)
            self.torque_z.append(msg.torque.z)

    # ──────────────────────────────────────────────────────
    def _image_cb(self, msg: Image):
        """Reçoit l'image caméra, détecte la sphère rouge, publie pixel."""
        try:
            cv_img = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().warn(f'cv_bridge: {e}')
            return

        # ── Détection par filtrage HSV ─────────────────────
        hsv  = cv2.cvtColor(cv_img, cv2.COLOR_BGR2HSV)

        # Rouge : deux plages de teinte dans HSV
        mask1 = cv2.inRange(hsv,
                             np.array([0,   120, 80]),
                             np.array([10,  255, 255]))
        mask2 = cv2.inRange(hsv,
                             np.array([160, 120, 80]),
                             np.array([180, 255, 255]))
        mask  = cv2.bitwise_or(mask1, mask2)

        # Erosion + dilatation pour supprimer le bruit
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask   = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel)
        mask   = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(
            mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        u, v = None, None
        if contours:
            largest = max(contours, key=cv2.contourArea)
            area    = cv2.contourArea(largest)
            if area > 30:   # filtre de surface minimale (px²)
                M = cv2.moments(largest)
                if M['m00'] > 0:
                    u = int(M['m10'] / M['m00'])
                    v = int(M['m01'] / M['m00'])

                    # ── Overlay sur l'image ────────────────
                    cv2.drawContours(cv_img, [largest], -1, (0, 255, 0), 2)
                    cv2.circle(cv_img, (u, v), 6, (0, 255, 0), -1)
                    cv2.putText(
                        cv_img,
                        f'({u}, {v})  A={int(area)}px',
                        (u + 10, max(v - 10, 15)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                        (0, 255, 100), 1, cv2.LINE_AA)

        # ── Mise à jour thread-safe ────────────────────────
        with self.lock:
            self.latest_img = cv_img.copy()
            self.detect_u   = u
            self.detect_v   = v

            if u is not None and self.t0 is not None:
                stamp = (msg.header.stamp.sec
                         + msg.header.stamp.nanosec * 1e-9
                         - self.t0)
                self.pixel_t.append(stamp)
                self.pixel_u.append(float(u))
                self.pixel_v.append(float(v))

        # ── Publication coordonnées pixel ──────────────────
        if u is not None:
            pt = Point()
            pt.x = float(u)
            pt.y = float(v)
            pt.z = 0.0
            self.pixel_pub.publish(pt)


# ──────────────────────────────────────────────────────────
# Helpers pour les sous-graphes
# ──────────────────────────────────────────────────────────

def _plot_xyz(ax, t, xb, yb, zb, title, ylabel,
              labels=('x', 'y', 'z'), colors=('r', 'g', 'b')):
    ax.cla()
    if len(t) < 2:
        ax.set_title(title)
        return
    t = np.asarray(t)
    ax.plot(t, np.asarray(xb), color=colors[0], lw=1.2, label=labels[0])
    ax.plot(t, np.asarray(yb), color=colors[1], lw=1.2, label=labels[1])
    ax.plot(t, np.asarray(zb), color=colors[2], lw=1.2, label=labels[2])
    ax.set_title(title, fontsize=9)
    ax.set_ylabel(ylabel, fontsize=8)
    ax.set_xlabel('t [s]', fontsize=7)
    ax.legend(fontsize=7, loc='upper right')
    ax.grid(True, alpha=0.35)
    ax.tick_params(labelsize=7)


# ──────────────────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = DronePlottingNode()

    # ── Spin ROS 2 dans un thread dédié ───────────────────
    spin_thread = threading.Thread(
        target=rclpy.spin, args=(node,), daemon=True)
    spin_thread.start()

    # ── Figure matplotlib (thread principal) ──────────────
    fig = plt.figure(figsize=(18, 11))
    fig.suptitle('Drone – Monitoring Temps Réel', fontsize=13, fontweight='bold')

    gs = fig.add_gridspec(3, 3, hspace=0.52, wspace=0.38)

    ax_pos     = fig.add_subplot(gs[0, 0])          # Position
    ax_vel     = fig.add_subplot(gs[0, 1])          # Vitesse linéaire
    ax_accl    = fig.add_subplot(gs[0, 2])          # Accél. linéaire
    ax_force   = fig.add_subplot(gs[1, 0])          # Force
    ax_torque  = fig.add_subplot(gs[1, 1])          # Couple
    ax_acca    = fig.add_subplot(gs[1, 2])          # Accél. angulaire
    ax_traj    = fig.add_subplot(gs[2, 0], projection='3d')  # Traj. 3D
    ax_pixels  = fig.add_subplot(gs[2, 1])          # Pixels u(t), v(t)
    ax_camera  = fig.add_subplot(gs[2, 2])          # Image caméra

    # ── Fonction de mise à jour de l'animation ─────────────
    def update(_frame):
        with node.lock:
            # Copies locales pour éviter blocage long
            t    = list(node.t_buf)
            px   = list(node.pos_x);  py  = list(node.pos_y);  pz  = list(node.pos_z)
            vx   = list(node.vel_x);  vy  = list(node.vel_y);  vz  = list(node.vel_z)
            alx  = list(node.acc_lx); aly = list(node.acc_ly); alz = list(node.acc_lz)
            aax  = list(node.acc_ax); aay = list(node.acc_ay); aaz = list(node.acc_az)
            fx   = list(node.force_x);  fy  = list(node.force_y);  fz  = list(node.force_z)
            tx   = list(node.torque_x); ty  = list(node.torque_y); tz  = list(node.torque_z)
            pt   = list(node.pixel_t)
            pu   = list(node.pixel_u); pv  = list(node.pixel_v)
            img  = node.latest_img

        # ── Ligne 1 ────────────────────────────────────────
        _plot_xyz(ax_pos,    t, px,  py,  pz,  'Position [m]',       'm')
        _plot_xyz(ax_vel,    t, vx,  vy,  vz,  'Vitesse lin. [m/s]', 'm/s')
        _plot_xyz(ax_accl,   t, alx, aly, alz, 'Accél. lin. [m/s²]', 'm/s²')

        # ── Ligne 2 ────────────────────────────────────────
        _plot_xyz(ax_force,  t, fx,  fy,  fz,
                  'Force cmd [N]',    'N',
                  labels=('Fx','Fy','Fz'), colors=('tomato','lime','dodgerblue'))
        _plot_xyz(ax_torque, t, tx,  ty,  tz,
                  'Couple cmd [N·m]', 'N·m',
                  labels=('Tx','Ty','Tz'), colors=('tomato','lime','dodgerblue'))
        _plot_xyz(ax_acca,   t, aax, aay, aaz, 'Accél. ang. [rad/s²]', 'rad/s²')

        # ── Trajectoire 3D ─────────────────────────────────
        ax_traj.cla()
        if len(px) > 1:
            ax_traj.plot(px, py, pz, 'b-', lw=1.2, label='Trajectoire')
            ax_traj.scatter([px[-1]], [py[-1]], [pz[-1]],
                            c='red', s=40, zorder=5, label='Position actuelle')
        ax_traj.set_title('Trajectoire 3D', fontsize=9)
        ax_traj.set_xlabel('X [m]', fontsize=7)
        ax_traj.set_ylabel('Y [m]', fontsize=7)
        ax_traj.set_zlabel('Z [m]', fontsize=7)
        ax_traj.tick_params(labelsize=6)
        ax_traj.legend(fontsize=6)

        # ── Coordonnées pixel ──────────────────────────────
        ax_pixels.cla()
        if len(pt) > 1:
            ax_pixels.plot(pt, pu, 'c-',  lw=1.2, label='u (col)')
            ax_pixels.plot(pt, pv, 'm--', lw=1.2, label='v (ligne)')
        ax_pixels.set_title('Pixel centroïde objet', fontsize=9)
        ax_pixels.set_ylabel('px', fontsize=8)
        ax_pixels.set_xlabel('t [s]', fontsize=7)
        ax_pixels.legend(fontsize=7, loc='upper right')
        ax_pixels.grid(True, alpha=0.35)
        ax_pixels.tick_params(labelsize=7)

        # ── Image caméra ───────────────────────────────────
        ax_camera.cla()
        if img is not None:
            ax_camera.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
            ax_camera.set_title('Caméra — détection sphère', fontsize=9)
        else:
            ax_camera.set_title('Caméra (en attente…)', fontsize=9)
        ax_camera.axis('off')

    # ── Animation matplotlib ───────────────────────────────
    ani = animation.FuncAnimation(
        fig, update,
        interval=200,    # 5 Hz de rafraîchissement
        blit=False,
        cache_frame_data=False)

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.show()   # BLOQUE ici (thread principal) jusqu'à fermeture fenêtre

    # ── Arrêt propre ────────────────────────────────────────
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
