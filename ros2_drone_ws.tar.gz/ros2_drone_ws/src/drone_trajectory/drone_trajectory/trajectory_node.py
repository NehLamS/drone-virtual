#!/usr/bin/env python3
# ============================================================
#  trajectory_node.py
#  Nœud ROS 2 – Génération de trajectoire
#
#  Publie sur /drone/reference (DroneState) la consigne de
#  position, vitesse et orientation pour le drone.
#
#  Machine d'états :
#    TAKEOFF  → Monte vers la hauteur cible en maintenant
#               la position de départ du cercle
#    STABLE   → Attend que le drone soit stabilisé (2s)
#    CIRCLE   → Exécute la trajectoire circulaire continue
#
#  Paramètres (params.yaml) :
#    radius       [m]       rayon du cercle       (défaut: 2.0)
#    height       [m]       altitude de vol        (défaut: 3.0)
#    omega        [rad/s]   vitesse angulaire      (défaut: 0.5)
#    center_x     [m]       centre X du cercle     (défaut: 0.0)
#    center_y     [m]       centre Y du cercle     (défaut: 0.0)
#    stable_delay [s]       délai stabilisation    (défaut: 2.0)
# ============================================================

import math
import rclpy
from rclpy.node import Node
from drone_msgs.msg import DroneState


class TrajectoryNode(Node):

    def __init__(self):
        super().__init__('drone_trajectory')

        # ── Déclaration des paramètres ─────────────────────
        self.declare_parameter('radius',       2.0)
        self.declare_parameter('height',       3.0)
        self.declare_parameter('omega',        0.5)
        self.declare_parameter('center_x',     0.0)
        self.declare_parameter('center_y',     0.0)
        self.declare_parameter('stable_delay', 2.0)

        self.radius       = self.get_parameter('radius').value
        self.height       = self.get_parameter('height').value
        self.omega        = self.get_parameter('omega').value
        self.cx           = self.get_parameter('center_x').value
        self.cy           = self.get_parameter('center_y').value
        self.stable_delay = self.get_parameter('stable_delay').value

        # ── Publisher ──────────────────────────────────────
        self.ref_pub = self.create_publisher(DroneState, '/drone/reference', 10)

        # ── Subscriber : état courant (pour takeoff logic) ─
        self.current_z  = 0.5   # hauteur supposée initiale
        self.current_vz = 0.0
        self.state_sub  = self.create_subscription(
            DroneState, '/drone/state', self._state_cb, 10)

        # ── Machine d'états ─────────────────────────────────
        self.phase        = 'TAKEOFF'
        self.t_stable     = 0.0   # compteur de stabilisation
        self.t_circle     = 0.0   # temps dans la phase CIRCLE

        # ── Timer (20 Hz) ──────────────────────────────────
        self.dt    = 0.05
        self.timer = self.create_timer(self.dt, self._update)

        self.get_logger().info(
            f'[Trajectory] Démarrage — r={self.radius}m  '
            f'h={self.height}m  ω={self.omega} rad/s')
        self.get_logger().info(
            f'[Trajectory] Centre = ({self.cx}, {self.cy})')

    # ── Callback état ──────────────────────────────────────
    def _state_cb(self, msg: DroneState):
        self.current_z  = msg.pose.position.z
        self.current_vz = msg.twist.linear.z

    # ── Boucle de mise à jour ─────────────────────────────
    def _update(self):
        msg = DroneState()
        msg.header.stamp    = self.get_clock().now().to_msg()
        msg.header.frame_id = 'world'

        # Position de départ du cercle (θ=0 → +X par rapport au centre)
        x0 = self.cx + self.radius
        y0 = self.cy

        if self.phase == 'TAKEOFF':
            # ── Phase TAKEOFF ──────────────────────────────
            # Consigne : position fixe au-dessus du point de départ du cercle
            msg.pose.position.x = x0
            msg.pose.position.y = y0
            msg.pose.position.z = self.height
            # Orientation neutre (quaternion identité)
            msg.pose.orientation.w = 1.0
            # Vitesse nulle (le contrôleur gère le déplacement)
            msg.twist.linear.x = 0.0
            msg.twist.linear.y = 0.0
            msg.twist.linear.z = 0.0

            # Transition → STABLE quand à moins de 0.25m de la hauteur cible
            if abs(self.current_z - self.height) < 0.25:
                self.t_stable += self.dt
                if self.t_stable >= self.stable_delay:
                    self.phase    = 'CIRCLE'
                    self.t_circle = 0.0
                    self.get_logger().info(
                        '[Trajectory] Hauteur atteinte → CIRCLE')
            else:
                self.t_stable = 0.0  # reset si on s'éloigne

        elif self.phase == 'CIRCLE':
            # ── Phase CIRCLE ───────────────────────────────
            self.t_circle += self.dt
            theta = self.omega * self.t_circle

            # Position sur le cercle (plan horizontal à hauteur constante)
            x = self.cx + self.radius * math.cos(theta)
            y = self.cy + self.radius * math.sin(theta)
            z = self.height

            # Vitesse (dérivée analytique)
            vx = -self.radius * self.omega * math.sin(theta)
            vy =  self.radius * self.omega * math.cos(theta)
            vz = 0.0

            # Accélération (dérivée de la vitesse, fournie pour feedforward)
            ax = -self.radius * self.omega**2 * math.cos(theta)
            ay = -self.radius * self.omega**2 * math.sin(theta)

            # Yaw : drone orienté dans la direction du mouvement tangentiel
            yaw = math.atan2(vy, vx)
            msg.pose.orientation.z = math.sin(yaw / 2.0)
            msg.pose.orientation.w = math.cos(yaw / 2.0)

            msg.pose.position.x = x
            msg.pose.position.y = y
            msg.pose.position.z = z

            msg.twist.linear.x  = vx
            msg.twist.linear.y  = vy
            msg.twist.linear.z  = vz

            # On stocke l'accélération de référence dans accel
            # (utilisable par le contrôleur en feedforward)
            msg.accel.linear.x = ax
            msg.accel.linear.y = ay
            msg.accel.linear.z = 0.0

        self.ref_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = TrajectoryNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
