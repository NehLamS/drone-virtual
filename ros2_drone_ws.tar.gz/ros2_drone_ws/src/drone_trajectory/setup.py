from setuptools import setup

package_name = 'drone_trajectory'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user',
    maintainer_email='user@example.com',
    description='Nœud de génération de trajectoire circulaire pour drone',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'trajectory_node = drone_trajectory.trajectory_node:main',
        ],
    },
)
