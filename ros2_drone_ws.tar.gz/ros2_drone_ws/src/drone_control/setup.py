from setuptools import setup

package_name = 'drone_control'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user',
    maintainer_email='user@example.com',
    description='Nœud contrôleur PD pour drone (ROS 2)',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'control_node = drone_control.control_node:main',
        ],
    },
)
