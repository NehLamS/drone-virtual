#!/usr/bin/env python3
# ============================================================
#  control_node.py
#  Nœud ROS 2 – Contrôleur PD du drone
#
#  Souscrit à :
#    /drone/state     (DroneState) – état courant
#    /drone/reference (DroneState) – consigne trajectoire
#
#  Publie sur :
#    /drone/cmd_wrench (geometry_msgs/Wrench) – forces/couples commandés
#
#  Architecture du contrôleur :
#    ┌─────────────────────────────────────────────────────────┐
#    │  Erreur position  →  Kp_pos * e_pos + Kd_pos * e_vel   │
#    │  Compensation gravité  →  +m*g selon Z monde            │
#    │  FeedForward accél  →  +m * accel_ref                   │
#    │                                                         │
#    │  Erreur attitude  →  Kp_att * e_att + Kd_att * e_omega  │
#    │  (maintien à plat : roll=0, pitch=0 + suivi yaw)        │
#    └─────────────────────────────────────────────────────────┘
#
#  Paramètres (params.yaml) :
#    mass        [kg]        masse du drone          (défaut: 1.5)
#    kp_pos      [N/m]       gain P position          (défaut: 5.0)
#    kd_pos      [N·s/m]     gain D vitesse           (défaut: 3.0)
#    kp_att      [N·m/rad]   gain P attitude          (défaut: 3.0)
#    kd_att      [N·m·s/rad] gain D ang. velocity     (défaut: 1.5)
#    max_force   [N]         saturation force         (défaut: 50.0)
#    max_torque  [N·m]       saturation couple        (défaut: 10.0)
# ============================================================

import math
import numpy as np
import rclpy
from rclpy.node import Node
from drone_msgs.msg import DroneState
from geometry_msgs.msg import Wrench


class ControlNode(Node):

    def __init__(self):
        super().__init__('drone_control')

        # ── Déclaration des paramètres ─────────────────────
        self.declare_parameter('mass',       1.5)
        self.declare_parameter('kp_pos',     5.0)
        self.declare_parameter('kd_pos',     3.0)
        self.declare_parameter('kp_att',     3.0)
        self.declare_parameter('kd_att',     1.5)
        self.declare_parameter('max_force',  50.0)
        self.declare_parameter('max_torque', 10.0)

        self.mass       = self.get_parameter('mass').value
        self.kp_pos     = self.get_parameter('kp_pos').value
        self.kd_pos     = self.get_parameter('kd_pos').value
        self.kp_att     = self.get_parameter('kp_att').value
        self.kd_att     = self.get_parameter('kd_att').value
        self.max_force  = self.get_parameter('max_force').value
        self.max_torque = self.get_parameter('max_torque').value

        self.g = 9.81  # m/s²

        # ── État interne ────────────────────────────────────
        self.current_state: DroneState | None = None
        self.reference:     DroneState | None = None

        # ── Subscribers ────────────────────────────────────
        self.state_sub = self.create_subscription(
            DroneState, '/drone/state', self._state_cb, 10)
        self.ref_sub = self.create_subscription(
            DroneState, '/drone/reference', self._ref_cb, 10)

        # ── Publisher ──────────────────────────────────────
        self.wrench_pub = self.create_publisher(Wrench, '/drone/cmd_wrench', 10)

        # ── Boucle de contrôle (50 Hz) ─────────────────────
        self.timer = self.create_timer(0.02, self._control_loop)

        self.get_logger().info(
            f'[Control] Démarrage — mass={self.mass}kg  '
            f'Kp={self.kp_pos}  Kd={self.kd_pos}')

    # ── Callbacks ─────────────────────────────────────────
    def _state_cb(self, msg: DroneState):
        self.current_state = msg

    def _ref_cb(self, msg: DroneState):
        self.reference = msg

    # ── Utilitaire : quaternion → angles d'Euler (rpy) ───
    @staticmethod
    def _quat_to_euler(q) -> tuple[float, float, float]:
        """Conversion quaternion (x,y,z,w) → (roll, pitch, yaw) en radians."""
        # Roll
        sinr = 2.0 * (q.w * q.x + q.y * q.z)
        cosr = 1.0 - 2.0 * (q.x**2 + q.y**2)
        roll = math.atan2(sinr, cosr)
        # Pitch
        sinp = 2.0 * (q.w * q.y - q.z * q.x)
        sinp = max(-1.0, min(1.0, sinp))   # clamp pour asin
        pitch = math.asin(sinp)
        # Yaw
        siny = 2.0 * (q.w * q.z + q.x * q.y)
        cosy = 1.0 - 2.0 * (q.y**2 + q.z**2)
        yaw = math.atan2(siny, cosy)
        return roll, pitch, yaw

    @staticmethod
    def _angle_wrap(angle: float) -> float:
        """Ramène un angle dans [-π, π]."""
        return math.atan2(math.sin(angle), math.cos(angle))

    # ── Boucle de contrôle principale ─────────────────────
    def _control_loop(self):
        if self.current_state is None or self.reference is None:
            # Publier zéro tant que pas de données (sécurité)
            self.wrench_pub.publish(Wrench())
            return

        cs  = self.current_state
        ref = self.reference

        # ── 1. Erreurs de POSITION (repère monde) ─────────
        ex = ref.pose.position.x - cs.pose.position.x
        ey = ref.pose.position.y - cs.pose.position.y
        ez = ref.pose.position.z - cs.pose.position.z

        # ── 2. Erreurs de VITESSE LINÉAIRE ─────────────────
        evx = ref.twist.linear.x - cs.twist.linear.x
        evy = ref.twist.linear.y - cs.twist.linear.y
        evz = ref.twist.linear.z - cs.twist.linear.z

        # ── 3. Commande de FORCE (repère monde) ────────────
        # PD + compensation gravité + feedforward accélération
        fx = (self.kp_pos * ex + self.kd_pos * evx
              + self.mass * ref.accel.linear.x)
        fy = (self.kp_pos * ey + self.kd_pos * evy
              + self.mass * ref.accel.linear.y)
        fz = (self.kp_pos * ez + self.kd_pos * evz
              + self.mass * self.g               # compensation gravité
              + self.mass * ref.accel.linear.z)  # feedforward vertical

        # Saturation des forces
        fx = float(np.clip(fx, -self.max_force, self.max_force))
        fy = float(np.clip(fy, -self.max_force, self.max_force))
        fz = float(np.clip(fz,  0.0,            self.max_force))  # poussée ≥ 0

        # ── 4. Contrôle d'ATTITUDE ─────────────────────────
        roll_c,  pitch_c,  yaw_c  = self._quat_to_euler(cs.pose.orientation)
        _,       _,        yaw_r  = self._quat_to_euler(ref.pose.orientation)

        # Objectif : drone à plat (roll=0, pitch=0) + suivi du yaw de référence
        e_roll  = self._angle_wrap(0.0   - roll_c)
        e_pitch = self._angle_wrap(0.0   - pitch_c)
        e_yaw   = self._angle_wrap(yaw_r - yaw_c)

        # Erreurs de vitesse angulaire
        e_wx = 0.0 - cs.twist.angular.x  # vitesse de roulis → 0
        e_wy = 0.0 - cs.twist.angular.y  # vitesse de tangage → 0
        e_wz = 0.0 - cs.twist.angular.z  # vitesse lacet → 0

        # Commande de couple (repère corps → AddRelativeTorque dans le plugin)
        tx = self.kp_att * e_roll  + self.kd_att * e_wx
        ty = self.kp_att * e_pitch + self.kd_att * e_wy
        tz = self.kp_att * e_yaw   + self.kd_att * e_wz

        # Saturation des couples
        tx = float(np.clip(tx, -self.max_torque, self.max_torque))
        ty = float(np.clip(ty, -self.max_torque, self.max_torque))
        tz = float(np.clip(tz, -self.max_torque, self.max_torque))

        # ── 5. Publication du wrench ───────────────────────
        w = Wrench()
        w.force.x  = fx;  w.force.y  = fy;  w.force.z  = fz
        w.torque.x = tx;  w.torque.y = ty;  w.torque.z = tz
        self.wrench_pub.publish(w)


def main(args=None):
    rclpy.init(args=args)
    node = ControlNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
