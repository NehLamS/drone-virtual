// ============================================================
//  drone_dynamics_plugin.cpp
//  Plugin Gazebo Classic – Dynamique drone pour ROS 2 Humble
//
//  Topics :
//    Pub : /drone/state  (drone_msgs/DroneState)
//    Sub : /drone/cmd_wrench (geometry_msgs/Wrench)
//
//  Repères :
//    Forces  → monde (AddForce)
//    Couples → monde (AddTorque)
//    [le nœud de contrôle travaille en monde pour les forces
//     et exprime les couples en repère corps, transformés ici]
// ============================================================

#include "drone_dynamics/drone_dynamics_plugin.hpp"

namespace gazebo
{

// ──────────────────────────────────────────────────────────
DroneDynamicsPlugin::DroneDynamicsPlugin()
: ModelPlugin()
, cmd_force_(ignition::math::Vector3d::Zero)
, cmd_torque_(ignition::math::Vector3d::Zero)
, prev_lin_vel_(ignition::math::Vector3d::Zero)
, prev_ang_vel_(ignition::math::Vector3d::Zero)
{}

// ──────────────────────────────────────────────────────────
DroneDynamicsPlugin::~DroneDynamicsPlugin()
{
  // La connexion à l'événement est détruite automatiquement
  update_connection_.reset();
}

// ──────────────────────────────────────────────────────────
void DroneDynamicsPlugin::Load(physics::ModelPtr model, sdf::ElementPtr sdf)
{
  model_ = model;
  world_ = model->GetWorld();

  // ── Récupération du nom du lien depuis SDF ─────────────
  std::string link_name = "base_link";
  if (sdf->HasElement("link_name")) {
    link_name = sdf->Get<std::string>("link_name");
  }

  link_ = model_->GetLink(link_name);
  if (!link_) {
    gzerr << "[DroneDynamicsPlugin] Lien '" << link_name
          << "' introuvable dans le modèle !\n";
    return;
  }

  // ── Nœud ROS 2 via bridge gazebo_ros ───────────────────
  ros_node_ = gazebo_ros::Node::Get(sdf);

  // ── Publisher : état complet du drone ──────────────────
  state_pub_ = ros_node_->create_publisher<drone_msgs::msg::DroneState>(
    "/drone/state", rclcpp::QoS(10));

  // ── Subscriber : commande de wrench ────────────────────
  wrench_sub_ = ros_node_->create_subscription<geometry_msgs::msg::Wrench>(
    "/drone/cmd_wrench",
    rclcpp::QoS(10),
    std::bind(&DroneDynamicsPlugin::WrenchCallback, this, std::placeholders::_1));

  // ── Initialisation du temps ─────────────────────────────
  prev_sim_time_ = world_->SimTime();

  // ── Connexion au callback de mise à jour physique ───────
  update_connection_ = event::Events::ConnectWorldUpdateBegin(
    std::bind(&DroneDynamicsPlugin::OnUpdate, this));

  gzmsg << "[DroneDynamicsPlugin] Chargé sur le lien : " << link_name << "\n";
  gzmsg << "[DroneDynamicsPlugin] Pub  → /drone/state\n";
  gzmsg << "[DroneDynamicsPlugin] Sub  ← /drone/cmd_wrench\n";
}

// ──────────────────────────────────────────────────────────
void DroneDynamicsPlugin::WrenchCallback(
  const geometry_msgs::msg::Wrench::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(mutex_);
  cmd_force_  = ignition::math::Vector3d(
    msg->force.x,  msg->force.y,  msg->force.z);
  cmd_torque_ = ignition::math::Vector3d(
    msg->torque.x, msg->torque.y, msg->torque.z);
}

// ──────────────────────────────────────────────────────────
void DroneDynamicsPlugin::OnUpdate()
{
  // ── 1. Appliquer le wrench commandé ─────────────────────
  //    Forces en repère monde, couples en repère corps
  {
    std::lock_guard<std::mutex> lock(mutex_);
    link_->AddForce(cmd_force_);             // repère monde
    link_->AddRelativeTorque(cmd_torque_);   // repère corps (plus naturel pour un drone)
  }

  // ── 2. Lire l'état courant de Gazebo ────────────────────
  common::Time sim_time = world_->SimTime();
  double dt = (sim_time - prev_sim_time_).Double();

  auto pose    = link_->WorldPose();
  auto lin_vel = link_->WorldLinearVel();
  auto ang_vel = link_->WorldAngularVel();

  // ── 3. Calcul de l'accélération (dérivée numérique + Gazebo) ──
  ignition::math::Vector3d lin_accel = ignition::math::Vector3d::Zero;
  ignition::math::Vector3d ang_accel = ignition::math::Vector3d::Zero;

  if (!first_update_ && dt > 1e-9) {
    lin_accel = (lin_vel - prev_lin_vel_) / dt;
    ang_accel = (ang_vel - prev_ang_vel_) / dt;
  }

  // Gazebo fournit aussi WorldLinearAccel() – on peut l'utiliser en complément
  // (moins bruité car intégré dans le solveur ODE)
  // ignition::math::Vector3d lin_accel_ode = link_->WorldLinearAccel();

  prev_lin_vel_  = lin_vel;
  prev_ang_vel_  = ang_vel;
  prev_sim_time_ = sim_time;
  first_update_  = false;

  // ── 4. Construction et publication du message ────────────
  drone_msgs::msg::DroneState state_msg;

  // Header
  state_msg.header.stamp    = ros_node_->now();
  state_msg.header.frame_id = "world";

  // Pose (position + quaternion)
  state_msg.pose.position.x    = pose.Pos().X();
  state_msg.pose.position.y    = pose.Pos().Y();
  state_msg.pose.position.z    = pose.Pos().Z();
  state_msg.pose.orientation.x = pose.Rot().X();
  state_msg.pose.orientation.y = pose.Rot().Y();
  state_msg.pose.orientation.z = pose.Rot().Z();
  state_msg.pose.orientation.w = pose.Rot().W();

  // Twist (vitesses linéaire et angulaire, repère monde)
  state_msg.twist.linear.x  = lin_vel.X();
  state_msg.twist.linear.y  = lin_vel.Y();
  state_msg.twist.linear.z  = lin_vel.Z();
  state_msg.twist.angular.x = ang_vel.X();
  state_msg.twist.angular.y = ang_vel.Y();
  state_msg.twist.angular.z = ang_vel.Z();

  // Accel (accélérations linéaire et angulaire, repère monde)
  state_msg.accel.linear.x  = lin_accel.X();
  state_msg.accel.linear.y  = lin_accel.Y();
  state_msg.accel.linear.z  = lin_accel.Z();
  state_msg.accel.angular.x = ang_accel.X();
  state_msg.accel.angular.y = ang_accel.Y();
  state_msg.accel.angular.z = ang_accel.Z();

  // Force et couple commandés (snapshot thread-safe)
  {
    std::lock_guard<std::mutex> lock(mutex_);
    state_msg.force.x  = cmd_force_.X();
    state_msg.force.y  = cmd_force_.Y();
    state_msg.force.z  = cmd_force_.Z();
    state_msg.torque.x = cmd_torque_.X();
    state_msg.torque.y = cmd_torque_.Y();
    state_msg.torque.z = cmd_torque_.Z();
  }

  state_pub_->publish(state_msg);
}

// ── Enregistrement du plugin dans Gazebo ────────────────
GZ_REGISTER_MODEL_PLUGIN(DroneDynamicsPlugin)

}  // namespace gazebo
