#ifndef DRONE_DYNAMICS__DRONE_DYNAMICS_PLUGIN_HPP_
#define DRONE_DYNAMICS__DRONE_DYNAMICS_PLUGIN_HPP_

// ============================================================
//  drone_dynamics_plugin.hpp
//  Plugin Gazebo Classic (ModelPlugin) pour ROS 2 Humble
//
//  Rôle :
//    - S'accroche au moteur physique Gazebo à chaque step de simulation
//    - Applique le wrench commandé (forces/couples) sur base_link
//    - Publie l'état complet du drone (pose, twist, accel, force, torque)
//      sur /drone/state
//    - Souscrit aux commandes de wrench sur /drone/cmd_wrench
// ============================================================

#include <mutex>
#include <string>

// Gazebo
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>

// gazebo_ros bridge (ROS 2)
#include <gazebo_ros/node.hpp>

// ROS 2 messages
#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/wrench.hpp>
#include <drone_msgs/msg/drone_state.hpp>

namespace gazebo
{

class DroneDynamicsPlugin : public ModelPlugin
{
public:
  DroneDynamicsPlugin();
  ~DroneDynamicsPlugin() override;

  // Appelé une fois par Gazebo lors du chargement du plugin
  void Load(physics::ModelPtr model, sdf::ElementPtr sdf) override;

private:
  // Callback appelé à chaque step de simulation
  void OnUpdate();

  // Callback sur reception d'une commande wrench ROS 2
  void WrenchCallback(const geometry_msgs::msg::Wrench::SharedPtr msg);

  // ── Gazebo ──────────────────────────────────────────────
  physics::ModelPtr  model_;
  physics::WorldPtr  world_;
  physics::LinkPtr   link_;

  event::ConnectionPtr update_connection_;

  // ── ROS 2 ───────────────────────────────────────────────
  gazebo_ros::Node::SharedPtr ros_node_;

  rclcpp::Publisher<drone_msgs::msg::DroneState>::SharedPtr state_pub_;
  rclcpp::Subscription<geometry_msgs::msg::Wrench>::SharedPtr wrench_sub_;

  // ── Commandes reçues (protégées par mutex) ───────────────
  std::mutex mutex_;
  ignition::math::Vector3d cmd_force_;   // N, repère monde
  ignition::math::Vector3d cmd_torque_;  // N.m, repère monde

  // ── Pour calcul numérique de l'accélération ──────────────
  ignition::math::Vector3d prev_lin_vel_;
  ignition::math::Vector3d prev_ang_vel_;
  common::Time             prev_sim_time_;

  bool first_update_ = true;
};

}  // namespace gazebo

#endif  // DRONE_DYNAMICS__DRONE_DYNAMICS_PLUGIN_HPP_
