#!/usr/bin/env python3
# ============================================================
#  drone_full.launch.py
#  Fichier de lancement global du projet drone
#
#  Lance dans l'ordre :
#    1. Serveur Gazebo (gzserver) + monde
#    2. Client Gazebo (gzclient) — vue 3D
#    3. robot_state_publisher (URDF → TF)
#    4. spawn_entity (instanciation du drone dans Gazebo)
#    5. drone_trajectory — génération de consignes
#    6. drone_control    — contrôleur PD
#    7. drone_plotting   — visualisation matplotlib
#
#  Variables d'environnement gérées automatiquement :
#    GAZEBO_PLUGIN_PATH  ← pointe vers libdrone_dynamics_plugin.so
#    GAZEBO_MODEL_PATH   ← modèles Gazebo standards
# ============================================================

import os
import xacro

from ament_index_python.packages import get_package_share_directory

from launch                            import LaunchDescription
from launch.actions                    import (ExecuteProcess,
                                               SetEnvironmentVariable,
                                               TimerAction,
                                               LogInfo)
from launch_ros.actions                import Node


def generate_launch_description():

    # ── Chemins des packages installés ───────────────────
    pkg_desc     = get_package_share_directory('drone_description')
    pkg_dynamics = get_package_share_directory('drone_dynamics')
    pkg_bringup  = get_package_share_directory('drone_bringup')

    world_file   = os.path.join(pkg_desc,    'worlds', 'drone_world.world')
    xacro_file   = os.path.join(pkg_desc,    'urdf',   'drone.xacro')
    params_file  = os.path.join(pkg_bringup, 'config', 'params.yaml')

    # ── Conversion Xacro → URDF (au moment du launch) ────
    robot_desc_xml = xacro.process_file(xacro_file).toxml()

    # ── GAZEBO_PLUGIN_PATH ────────────────────────────────
    # Après colcon build, le plugin est dans :
    #   install/drone_dynamics/lib/
    # get_package_share_directory renvoie :
    #   install/drone_dynamics/share/drone_dynamics
    # On remonte de 2 niveaux pour atteindre install/drone_dynamics/lib
    plugin_lib_path = os.path.normpath(
        os.path.join(pkg_dynamics, '..', '..', 'lib'))

    existing_plugin_path = os.environ.get('GAZEBO_PLUGIN_PATH', '')
    full_plugin_path = (
        f"{plugin_lib_path}:{existing_plugin_path}"
        if existing_plugin_path else plugin_lib_path
    )

    # ── Description du lancement ──────────────────────────
    return LaunchDescription([

        # ── 0. Variables d'environnement ──────────────────
        SetEnvironmentVariable('GAZEBO_PLUGIN_PATH', full_plugin_path),

        LogInfo(msg=['GAZEBO_PLUGIN_PATH = ', full_plugin_path]),
        LogInfo(msg=['Monde Gazebo       = ', world_file]),
        LogInfo(msg=['URDF               = ', xacro_file]),

        # ── 1. Serveur Gazebo ─────────────────────────────
        ExecuteProcess(
            cmd=[
                'gzserver', '--verbose',
                '-s', 'libgazebo_ros_init.so',
                '-s', 'libgazebo_ros_factory.so',
                world_file
            ],
            output='screen',
            additional_env={'GAZEBO_PLUGIN_PATH': full_plugin_path},
        ),

        # ── 2. Client Gazebo (GUI 3D) ─────────────────────
        ExecuteProcess(
            cmd=['gzclient'],
            output='screen',
        ),

        # ── 3. Robot State Publisher ──────────────────────
        #    Publie les TF depuis l'URDF + /robot_description
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{
                'robot_description': robot_desc_xml,
                'use_sim_time': True,
            }],
        ),

        # ── 4. Spawn du drone dans Gazebo ─────────────────
        #    Délai de 3 s pour laisser gzserver démarrer
        TimerAction(
            period=3.0,
            actions=[
                Node(
                    package='gazebo_ros',
                    executable='spawn_entity.py',
                    name='spawn_drone',
                    output='screen',
                    arguments=[
                        '-entity',        'drone',
                        '-topic',         'robot_description',
                        '-x',  '2.0',   # position initiale = départ du cercle
                        '-y',  '0.0',
                        '-z',  '3.0',   # hauteur de trajectoire (pas de décollage long)
                        '-Y',  '1.571', # cap initial vers +Y (tangent au cercle en x=r)
                    ],
                ),
                LogInfo(msg='Spawn du drone demandé…'),
            ],
        ),

        # ── 5. Nœud de trajectoire ─────────────────────────
        #    Délai de 5 s pour que Gazebo et le drone soient prêts
        TimerAction(
            period=5.0,
            actions=[
                Node(
                    package='drone_trajectory',
                    executable='trajectory_node',
                    name='drone_trajectory',
                    output='screen',
                    parameters=[params_file],
                ),
                LogInfo(msg='Nœud trajectoire démarré'),
            ],
        ),

        # ── 6. Contrôleur PD ──────────────────────────────
        TimerAction(
            period=5.0,
            actions=[
                Node(
                    package='drone_control',
                    executable='control_node',
                    name='drone_control',
                    output='screen',
                    parameters=[params_file],
                ),
                LogInfo(msg='Contrôleur PD démarré'),
            ],
        ),

        # ── 7. Nœud de visualisation ──────────────────────
        #    Délai supplémentaire pour que l'état soit disponible
        TimerAction(
            period=6.0,
            actions=[
                Node(
                    package='drone_plotting',
                    executable='plotting_node',
                    name='drone_plotting',
                    output='screen',
                    # Fenêtre matplotlib dans le thread principal du nœud :
                    # ne pas préfixer avec ros2 launch --prefix xterm
                    # (le nœud gère lui-même le thread ROS vs matplotlib)
                ),
                LogInfo(msg='Nœud de visualisation démarré'),
            ],
        ),

    ])
