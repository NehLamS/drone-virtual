# Drone Simulation — ROS 2 Humble + Gazebo Classic

Environnement minimaliste mais complet pour l'enseignement/recherche en robotique aérienne.

---

## Architecture des packages

```
ros2_drone_ws/src/
├── drone_msgs/          # Message custom DroneState
├── drone_description/   # URDF/Xacro + monde Gazebo
├── drone_dynamics/      # Plugin Gazebo C++ (physique + publication état)
├── drone_trajectory/    # Nœud Python — trajectoire circulaire
├── drone_control/       # Nœud Python — contrôleur PD
├── drone_plotting/      # Nœud Python — matplotlib + OpenCV
└── drone_bringup/       # Launch file global + params.yaml
```

---

## Topics ROS 2

| Topic | Type | Direction | Description |
|---|---|---|---|
| `/drone/state` | `DroneState` | Plugin → | Pose, twist, accel, force, couple |
| `/drone/reference` | `DroneState` | Trajectory → | Consigne de position/vitesse |
| `/drone/cmd_wrench` | `Wrench` | Control → | Force + couple commandés |
| `/camera/image_raw` | `Image` | Plugin → | Flux caméra perspective |
| `/camera/camera_info` | `CameraInfo` | Plugin → | Paramètres intrinsèques |
| `/drone/pixel_coords` | `Point` | Plotting → | (u, v) centroïde sphère rouge |

---

## Prérequis

```bash
# ROS 2 Humble
sudo apt install ros-humble-desktop

# Gazebo Classic (Gazebo 11) + bridge ROS 2
sudo apt install gazebo libgazebo-dev ros-humble-gazebo-ros-pkgs

# Dépendances Python
sudo apt install ros-humble-cv-bridge python3-opencv python3-matplotlib
sudo apt install ros-humble-xacro ros-humble-robot-state-publisher
```

---

## Build

```bash
# Se placer dans le workspace
cd ~/ros2_drone_ws

# Sourcer ROS 2
source /opt/ros/humble/setup.bash

# Compiler tous les packages
colcon build --symlink-install

# Sourcer l'environnement du workspace
source install/setup.bash
```

> **Note** : La première compilation du plugin C++ (`drone_dynamics`) peut prendre
> quelques dizaines de secondes. Les packages Python sont instantanés.

---

## Lancement

```bash
# Dans un terminal (après source du workspace)
ros2 launch drone_bringup drone_full.launch.py
```

Cela démarre automatiquement (avec délais intégrés) :
1. **Gazebo** avec le monde `drone_world.world`
2. **robot_state_publisher** (TF depuis URDF)
3. **Spawn** du drone à (2, 0, 3) — départ du cercle
4. **drone_trajectory** — génération de la trajectoire
5. **drone_control** — boucle de contrôle PD à 50 Hz
6. **drone_plotting** — fenêtre matplotlib + détection OpenCV

---

## Lancement individuel des nœuds

Si tu veux démarrer les nœuds séparément pour débogage :

```bash
# Terminal 1 — Gazebo
export GAZEBO_PLUGIN_PATH=$GAZEBO_PLUGIN_PATH:~/ros2_drone_ws/install/drone_dynamics/lib
ros2 launch gazebo_ros gazebo.launch.py world:=~/ros2_drone_ws/install/drone_description/share/drone_description/worlds/drone_world.world

# Terminal 2 — Robot State Publisher + spawn
ros2 run robot_state_publisher robot_state_publisher --ros-args -p robot_description:="$(xacro ~/ros2_drone_ws/install/drone_description/share/drone_description/urdf/drone.xacro)"
ros2 run gazebo_ros spawn_entity.py -entity drone -topic robot_description -x 2 -y 0 -z 3

# Terminal 3 — Trajectoire
ros2 run drone_trajectory trajectory_node --ros-args --params-file ~/ros2_drone_ws/install/drone_bringup/share/drone_bringup/config/params.yaml

# Terminal 4 — Contrôleur
ros2 run drone_control control_node --ros-args --params-file ~/ros2_drone_ws/install/drone_bringup/share/drone_bringup/config/params.yaml

# Terminal 5 — Visualisation
ros2 run drone_plotting plotting_node
```

---

## Modification des paramètres

Édite `drone_bringup/config/params.yaml` avant le build :

```yaml
drone_trajectory:
  ros__parameters:
    radius: 2.0        # rayon du cercle [m]
    height: 3.0        # altitude [m]
    omega:  0.5        # vitesse angulaire [rad/s]

drone_control:
  ros__parameters:
    mass:      1.5     # kg
    kp_pos:    5.0     # gain P position [N/m]
    kd_pos:    3.0     # gain D vitesse  [N·s/m]
    kp_att:    3.0     # gain P attitude [N·m/rad]
    kd_att:    1.5     # gain D ω        [N·m·s/rad]
```

---

## Visualisation matplotlib

La fenêtre `drone_plotting` affiche une grille 3×3 :

```
┌──────────────┬──────────────┬──────────────┐
│  Position    │  Vitesse     │  Accél. lin. │
│  x, y, z    │  vx, vy, vz  │  ax, ay, az  │
├──────────────┼──────────────┼──────────────┤
│  Force cmd   │  Couple cmd  │  Accél. ang. │
│  Fx, Fy, Fz  │  Tx, Ty, Tz  │  αx, αy, αz  │
├──────────────┼──────────────┼──────────────┤
│  Traj. 3D   │  Pixels      │  Caméra      │
│  XYZ         │  u(t), v(t)  │  + détection │
└──────────────┴──────────────┴──────────────┘
```

La **détection de la sphère rouge** utilise un filtrage HSV double plage
(rouge passe sur H ∈ [0°,10°] ∪ [160°,180°]) + morphologie + centroïde.

---

## Architecture du message DroneState

```
std_msgs/Header header        # timestamp + frame_id = "world"
geometry_msgs/Pose pose       # position [m] + quaternion
geometry_msgs/Twist twist     # v_lin [m/s] + v_ang [rad/s]  — repère monde
geometry_msgs/Accel accel     # a_lin [m/s²] + a_ang [rad/s²] — repère monde
geometry_msgs/Vector3 force   # force appliquée [N] — repère monde
geometry_msgs/Vector3 torque  # couple appliqué [N·m] — repère corps
```

---

## Repères et conventions

| Grandeur | Repère | API Gazebo |
|---|---|---|
| Force commandée | **Monde** | `AddForce()` |
| Couple commandé | **Corps** | `AddRelativeTorque()` |
| Pose publiée | Monde | `WorldPose()` |
| Twist publié | Monde | `WorldLinearVel()` / `WorldAngularVel()` |
| Accélération | Monde | dérivée numérique des vitesses |

---

## Problèmes courants

**Plugin non trouvé (Gazebo)**
```
[GAZEBO] Failed to load plugin : libdrone_dynamics_plugin.so
```
→ Vérifier que `GAZEBO_PLUGIN_PATH` inclut `install/drone_dynamics/lib/`.
Le launch file le configure automatiquement.

**matplotlib ne s'affiche pas**
→ Changer le backend dans `plotting_node.py` :
```python
matplotlib.use('Qt5Agg')   # ou 'GTK3Agg', 'WebAgg'
```

**Drone qui tombe**
→ La compensation de gravité dépend du paramètre `mass`.
Vérifier qu'il est cohérent avec la masse déclarée dans le URDF (`body_mass` dans `drone.xacro`).

---

## Structure pédagogique

Ce projet est volontairement décomposé pour l'enseignement :

- Modifier **uniquement la trajectoire** → ne toucher qu'à `trajectory_node.py`
- Tester un **nouveau contrôleur** (LQR, MPC…) → ne remplacer que `control_node.py`
- Ajouter un **observateur** → créer un 8ème package et souscrire à `/drone/state`
- Changer le **modèle physique** → modifier `drone_dynamics_plugin.cpp`

Chaque nœud est indépendant et communique uniquement via des topics ROS 2.
